<template>
  <div class="container mt-5">
    <h1 class="text-center mb-5">Registration Form</h1>
    
    <div class="row justify-content-center">
      <div class="col-md-8 col-lg-6">
        <RegistrationForm />
      </div>
    </div>
  </div>
</template>

<script setup>
import RegistrationForm from '@/components/RegistrationForm.vue'
</script>
